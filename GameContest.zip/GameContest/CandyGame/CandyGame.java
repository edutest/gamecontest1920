import java.io.*;
/**
* 
* e' la versione del gioco che portiamo avanti!!
* @version 10.06.2020
*/
public class CandyGame{
	public static void stampa(int millisecondi, int righe, int colonne, String tipoCaramella, String cestino, int vite, String cuore) throws IOException{
		String[][] areaCaramelle = new String[righe][colonne];
		String caramella = tipoCaramella;
		int punteggio = 0;
		int location = (int)(colonne/2);
		areaCaramelle[righe-2][location] = cestino;
		int contatore = 0;
		do{
			int volte = righe;
			contatore++;
			copiaMatrice(areaCaramelle);
			int cadutaCaramelle1 = Math.max((int)(Math.random() * colonne - 1), 2);
			do{
				System.out.print("Punti :" + punteggio);
				System.out.print("\r\n");
				copiaMatrice(areaCaramelle);
				for (int i = 0; i < righe ; i++){
					for (int j = 0; j < colonne; j++){
							if(System.in.available() > 0){
								int inputRead = System.in.read();
								if(inputRead == 'a'){
									location--;
								}else if(inputRead == 'd'){
									location++;
								} else if(inputRead == 'q'){
									System.exit(0);
								}
							}
						if(location == 1){
							location++;
						}else if(location == colonne-1){
							location--;
						}
						if(location != 2 && location != colonne-2){
							areaCaramelle[righe-2][location+1] = " ";
							areaCaramelle[righe-2][location-1] = " ";
						}
						areaCaramelle[righe-2][location] = cestino;
						if(j == cadutaCaramelle1 && i == righe - volte && i > 0 /*&& i<righe-1*/){
						boolean dump = false;
							if(i == righe - 1){
								vite-=1;
								volte = 0;
								dump = true;
							}
							if(areaCaramelle[i][j].equals(cestino)){
								dump = true;
								punteggio +=10;
								if(punteggio%50 == 0){
									vite++;
								}
								volte = 0;
							}
							if(!dump){
								areaCaramelle[i][j] = caramella;
							}
							dump = true;
						}
						System.out.print(areaCaramelle[i][j]);
					}
					System.out.print("\r\n");	
				}
				for(int i = 0; i<vite; i++){
					System.out.print(cuore+ "  ");
				}
				try{
					Thread.sleep(Math.min(Math.abs((long)(millisecondi/Math.sin(contatore)/3)),450));
				}catch(InterruptedException ie){}
				volte--;
				cancella();
			}while(volte > 0);

		}while(vite >= 1);
		morte(punteggio);
	}
	
	public static void morte(int punteggio) throws IOException{
		String finale = "GAME OVER";
		for(int i = 0; i<finale.length(); i++){
			System.out.print(finale.charAt(i));
			try{
				Thread.sleep(400);
			}catch(InterruptedException ie){}
		}
		System.out.print("\r\n");
		System.out.print("Punti: "+ punteggio);
		System.out.print("\r\n");
		System.out.print("\r\n");	
		System.out.print("premere 'm' per riaprire il menu' o 'q' per chiudere il programma");
			boolean corretto = false;
			do{
				if(System.in.available() > 0){
				int inputRead = System.in.read();
					if(inputRead == 'm'){
						corretto = true;
						menu();
					}else if(inputRead == 'q'){
						System.exit(0);
					}
				}
			}while(!corretto);
	}
	
	public static void cancella(){
        System.out.print("\033[H\033[2J");
        System.out.flush();
	}
	
	public static void copiaMatrice(String[][] areaCaramelle){
		for(int i = 0; i<areaCaramelle.length ; i++){
			for(int j = 0; j<areaCaramelle[i].length; j++){
				if(i == 0 || j == areaCaramelle[i].length-1 || j == 0 || i == areaCaramelle.length-1){
					areaCaramelle[i][j] = "\u25A6";
				}else{
					areaCaramelle[i][j] = " ";
				}				
			}
		}
	}
	
	public static void menu() throws IOException{
		int millisecondi = 400;
		int righe = 20;
		int colonne = 40;
				/*\u1F5D1*/
		String cestino = "V";
		String tipoCaramella = "*";
		int vite = 3;
		String cuore = "\u2766";
		inizio(millisecondi, righe, colonne, tipoCaramella, cestino, vite, cuore);
	}
	
	public static void inizio(int millisecondi,int righe,int colonne,String tipoCaramella,String cestino,int vite,String cuore) throws IOException{
		cancella();
		System.out.print("\r\n");
		System.out.print("**************************************************************************************\r\n");
		System.out.print("*Questo gioco e' stato realizzato da Samuele Abba e Gioele Cavallo in data 10.06.2020*\r\n");
		System.out.print("**************************************************************************************\r\n");
		System.out.print("\r\n");
		System.out.print("IL gioco consiste nel prendere piu'caramelle possibili provenienti \r\n");
		System.out.print("dall'alto con un cestino apposito senza morire. Buon divertimento! \r\n");
		System.out.print("\r\n");
		System.out.print("Premi il tasto (g) per iniziare a giocare         \r\n");
		System.out.print("Premi il tasto (i) per entarare nelle impostazioni\r\n");
		System.out.print("Premi il tasto (q) per uscire dal gioco           \r\n");
		System.out.print("\r\n");
		System.out.print("Tasti per giocare:\r\n");
		System.out.print("sinistra    <--  a\r\n");
		System.out.print("destra      -->  d\r\n");
		System.out.print("uscire/menu -q-  q\r\n");
		System.out.print("\r\nTasto: ");
		do{
			if(System.in.available() > 0){
				int tasto = System.in.read();
				if(tasto == 'g'){
					System.out.print("\r\n");
					stampa(millisecondi, righe, colonne, tipoCaramella, cestino, vite, cuore);
					
				}else if(tasto == 'i'){
					System.out.print("\r\n");
					impostazioni();
				}else if(tasto == 'q'){
					System.out.print("\r\n");
					System.exit(0);
				}else{
					System.out.print("\r\n");
					System.out.print("Tasto non valido riprova: ");
				}
			}
		}while(true);
	}
	
	public static void impostazioni() throws IOException{
		cancella();
		System.out.print("\r\n");
		System.out.print("IMPOSTAZIONI\r\n");
		System.out.print("\r\n");
		System.out.print("ATTENZIONE: tutte le impostazioni visualizzate non si possono\r\n");
		System.out.print("cancellare o modificare, premere (q) per tornare al menu!\r\n");
		System.out.print("\r\n");
		System.out.print("Tasti per giocare:\r\n");
		System.out.print("sinistra    <--  a\r\n");
		System.out.print("destra      -->  d\r\n");
		System.out.print("uscire/menu -m-  q\r\n");
		System.out.print("\r\nTasto: ");
		do{
			if(System.in.available() > 0){
				int tasto = System.in.read();
				if(tasto == 'g'){
					
				}else if(tasto == 'q'){
					menu();
				}else{
					System.out.print("\r\n");
					System.out.print("Tasto non valido riprova: ");
				}
			}
		}while(true);
	}
	
	public static void main(String[] args){
		try{
			menu();
		}catch(IOException ioe){
			System.out.print("\r\n Inserire una tastiera");	
		}
	}
}
