#!/bin/bash
stty raw
java CandyGame
stty -raw
