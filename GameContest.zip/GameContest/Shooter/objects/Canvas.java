package objects;

public class Canvas {

  int width, height;
  char[][] matrix;
  String specialColor = "";
  int specialX = -1, specialY = -1;

  public Canvas(int width, int height) {
    this.width = width;
    this.height = height;
    matrix = new char[height][width];
  }

  public boolean fill(int x, int y , char c) {
    if (x >= 0 && x < matrix[0].length && matrix.length - y - 1 >= 0 && matrix.length - y - 1 < matrix.length) {
      matrix[matrix.length - y - 1][x] = c;
      return true;
    }
    return false;
  }

  public void fill(int x, int y, int width, int height, char c) {
    for (int i = y; i < y + height; i++) {
      for (int j = x; j < x + width; j++) {
        fill(j, i, c);
      }
    }
  }

  public void fill(char c) {
    fill(0, 0, matrix[0].length, matrix.length, c);
  }

  public void draw(int x, int y, int width, int height) {
    clear();
    for (int i = y; i < y + height; i++) {
      for (int j = x; j < x + width; j++) {
        if (specialX == j && matrix.length - 1 - specialY == i) {
          System.out.print(specialColor + matrix[i][j] + "\u001b[0m");
        } else {
          System.out.print(matrix[i][j]);
        }
      }
      System.out.print("\n \r");
    }
  }

  public void draw() {
    draw(0, 0, matrix[0].length, matrix.length);
  }

  public void setSpecialColor(String specialColor) {
    this.specialColor = specialColor;
  }

  public void setSpecialCell(int specialX, int specialY) {
    this.specialX = specialX;
    this.specialY = specialY;
  }

  public int getWidth() {
    return width;
  }

  public int getHeight() {
    return height;
  }

  public char getChar(int x, int y, char def) {
    if (x >= 0 && x < matrix[0].length && matrix.length - y - 1 >= 0
        && matrix.length - y - 1 < matrix.length) {
      return matrix[matrix.length - y - 1][x];
    }
    return def;
  }

  public void animate(Canvas ctx) {
    int[] array = new int[ctx.getHeight() * ctx.getWidth()];
    for (int i = 0; i < ctx.getHeight() * ctx.getWidth(); i++) {
      array[i] = i;
    }

    int temp, randomIndex;
    for (int i = 0; i < array.length; i++) {
      randomIndex = (int) (Math.random() * array.length);
      temp = array[randomIndex];
      array[randomIndex] = array[i];
      array[i] = temp;
    }

    int x, y;
    for (int i = 0; i < array.length; i++) {
      x = array[i] % ctx.getWidth();
      y = array[i] / ctx.getWidth();
      fill(x, y, ctx.getChar(x, y, 'E'));
      if (i % 40 == 0) {
        draw();
      }
    }
  }

  private void clear() {
    System.out.print("\033[H\033[2J");
    System.out.flush();
  }
}
