package objects;

public class Bullet {

  double x, y, angle;
  int dmg;
  Entity owner;

  public Bullet(Entity owner, double angle, int dmg) {
    x = owner.getX();
    y = owner.getY();
    this.owner = owner;
    this.dmg = dmg;
    this.angle = angle;
  }

  public Bullet(Entity owner, double targetX, double targetY, int dmg) {
    x = owner.getX();
    y = owner.getY();
    this.owner = owner;
    this.dmg = dmg;
    angle = Math.atan2(targetY - y, targetX - x);
  }

  public double getX() {
    return Math.round(x);
  }

  public double getY() {
    return Math.round(y);
  }

  public int getDMG() {
    return dmg;
  }

  public Entity getOwner() {
    return owner;
  }

  public void update() {
    x += Math.cos(angle);
    y += Math.sin(angle);
  }
}
