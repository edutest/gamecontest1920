package objects;

public class Entity {
  int x, y, health, dmg, range;
  boolean alive = true, canShoot = true;

  public Entity(int x, int y, int health, int dmg, int range) {
    this.x = x;
    this.y = y;
    this.health = health;
    this.dmg = dmg;
    this.range = range;
  }

  public boolean isAlive() {
    return alive;
  }

  public int getX() {
    return x;
  }

  public int getY() {
    return y;
  }

  public void teleport(int x, int y) {
    this.x = x;
    this.y = y;
  }

  public void step(int x, int y) {
    this.x += x;
    this.y += y;
  }

  public void takeDamage(int damage) {
    health -= damage;
    if (health <= 0) {
      alive = false;
    }
  }

  public int getRange() {
    return range;
  }

  public Bullet shoot(double x, double y) {
    return new Bullet(this, x, y, dmg);
  }
  
  public Bullet shoot(double angle) {
    return new Bullet(this, angle, dmg);
  }

  public void setShootPex(boolean canShoot) {
    this.canShoot = canShoot;
  }

  public boolean canShoot() {
    return canShoot;
  }

  public int getHealth() {
    return health;
  }
}
