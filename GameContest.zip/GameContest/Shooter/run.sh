#!/bin/bash
stty raw
javac Main.java
java Main
stty -raw
