import java.io.IOException;

/**
 * Programma Main
 * 
 * Videogioco SAMT I1BB 2019-2020 Shooter in terza persona dall'alto con menù
 * 
 * @author Paolo Bettelini
 * @version 18.06.2020
 */
public class Main {

  public static void main(String[] args) {
    Game game;

    while (true) {
      printMenu();
      switch (readLine()) {
        case 'q':
          clear();
          print("Bye!");
          return;
        case 't':
          printTutorial();
          readLine();
          break;
        default:
          game = new Game();
          game.execute();
          printGameOver(game.getScore());
          readLine();
          break;
      }
    }
  }

  private static void printMenu() {
    clear();
    print(""
      + "\r\n __  __"
      + "\r\n|  \\/  |"
      + "\r\n| \\  / | ___ _ __  _   _ "
      + "\r\n| |\\/| |/ _ \\ '_ \\| | | |"
      + "\r\n| |  | |  __/ | | | |_| |"
      + "\r\n|_|  |_|\\___|_| |_|\\__,_|"
    );
    print("");
    print("Menu:");
    print("");
    print("\tPress 't' for the tutorial");
    print("\tPress 'q' to quit");
    print("");
    print("\tPress any other key to play...");
  }

  private static void printGameOver(int score) {
    clear();
    print(""
     + "\r\n  _____"
     + "\r\n / ____|"
     + "\r\n| |  __  __ _ _ __ ___   ___"
     + "\r\n| | |_ |/ _` | '_ ` _ \\ / _ \\"
     + "\r\n| |__| | (_| | | | | | |  __/"
     + "\r\n \\_____|\\__,_|_| |_| |_|\\___|"
     + "\r\n  ____"
     + "\r\n / __ \\"   
     + "\r\n| |  | |_   _____ _ __"    
     + "\r\n| |  | \\ \\ / / _ \\ '__|"      
     + "\r\n| |__| |\\ V /  __/ |"        
     + "\r\n \\____/  \\_/ \\___|_|"
    );
    print("");
    print("You lost:");
    print("");
    print("\tYou score: " + score);
    print("");
    print("\tPress any key to continue...");
  }

  private static void printTutorial() {
    clear();
    print(""
      + "\r\n _______    _             _       _"
      + "\r\n|__   __|  | |           (_)     | |"
      + "\r\n   | |_   _| |_ ___  _ __ _  __ _| |"
      + "\r\n   | | | | | __/ _ \\| '__| |/ _` | |"
      + "\r\n   | | |_| | || (_) | |  | | (_| | |"
      + "\r\n   |_|\\__,_|\\__\\___/|_|  |_|\\__,_|_|"
    );
    print("");
    print("TUTORIAL:");
    print("");
    print("\tPress 'w' to move up");
    print("\tPress 'a' to move left");
    print("\tPress 's' to move down");
    print("\tPress 'd' to move right");
    print("\tPress 'Shift' + 'a' to move your viewfinder anticlockwise");
    print("\tPress 'Shift' + 'd' to move your viewfinder clockwise");
    print("\tPress 'Space' to shoot");
    print("");
    print("\t\u2022  are bullets");
    print("\t\u2689  are enemies");
    print("\t\u2620  are dead enemies");
    print("\t\u269D  is your character");
    print("\t\u2629  is your viewfinder");
    print("\t\u2764  increases your health");
    print("\t\u2744  freezes enemies for 3 seconds");
    print("");
    print("\tPress any key to go back...");
  }

  private static void print(String msg) {
    System.out.print("\r" + msg + "\r\n");
  }

  private static char readLine() {
    try {
      while (true) {
        if (System.in.available() > 0) {
          return (char) System.in.read();
        }
        Thread.sleep(25);
      }
    } catch (IOException | InterruptedException e) {
      return '!';
    }
  }

  private static void clear() {
    System.out.print("\033[H\033[2J");
    System.out.flush();
  }
}
