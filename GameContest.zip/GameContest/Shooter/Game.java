import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import objects.Canvas;
import objects.Entity;
import objects.Bullet;

public class Game {

  int FPS = 35, width = 83, height = 42, score = 0, aimDistance = 6,
    killsPerSupply = 10, killsPerDifficultyIncrement = 10, msSpawnRate = 4500,
    msEnemyMovement = 100, msDeathAnimation = 2000,
    freezeSpawnRate = 20, freezingTime = 3, currentFreeze = 0;
  char enemyChar = '\u2689', playerChar = '\u269D', bulletChar = '\u2022',
    aimChar = '\u2629', dyingEnemy = '\u2620', scoreChar = '\u2694',
    healthChar = '\u2764', freezeChar = '\u2744';
  double aimAngle = Math.PI / 2, aimAngleIncrement = .1, shellRatio = 2.0;
  Entity player = new Entity(width / 2, height / 2, 10, 1, -1),
    healthSupply = null, freeze = null;
  ArrayList<Entity> enemies = new ArrayList<>();
  ArrayList<Bullet> enemyBullets = new ArrayList<>(),
    playerBullets = new ArrayList<>();
  HashMap<Entity, Integer> dying = new HashMap<>();
  Canvas ctx = new Canvas(width, height);
  int spawnX = -1, spawnY = -1, framePerSpawn = msSpawnRate * FPS / 1000,
    framePerFreezeSpawn = freezeSpawnRate * FPS,
    frameFreezingTime = freezingTime * FPS;
  Iterator<Map.Entry<Entity, Integer>> iterator;
  boolean canHealthSupplySpawn = true;

  public Game() {}

  public void execute() {
    ctx.setSpecialColor("\u001b[32m");
    for (int frame = 1; frame < Integer.MAX_VALUE; frame++) {
      ctx.fill(' ');
      try {
        if (System.in.available() > 0) {
          switch (System.in.read()) {
            case 'w':
              if (player.getY() != ctx.getHeight() - 1) {
                player.step(0, 1);
              }
              break;
            case 'a':
              if (player.getX() != 0) {
                player.step(-1, 0);
              }
              break;
            case 's':
              if (player.getY() != 0) {
                player.step(0, -1);
              }
              break;
            case 'd':
              if (player.getX() != ctx.getWidth() - 1) {
                player.step(1, 0);
              }
              break;
            case 'A':
              aimAngle += aimAngleIncrement;
              break;
            case 'D':
              aimAngle -= aimAngleIncrement;
              break;
            case ' ':
              playerBullets.add(player.shoot(shellRatio * aimDistance
                * Math.cos(aimAngle) + player.getX(), aimDistance 
                * Math.sin(aimAngle) + player.getY()));
              break;
            case 'q':
              player.takeDamage(player.getHealth());
          }
        }
      } catch (IOException e) {
        return;
      }

      if (frame % framePerFreezeSpawn == 0) {
        freeze = new Entity((int) (Math.random() * ctx.getWidth()),
          (int) (Math.random() * ctx.getHeight()), -1, -1, -1);
      }

      if (currentFreeze != 0) {
        currentFreeze--;
      }

      for (int i = 0; i < playerBullets.size(); i++) {
        playerBullets.get(i).update();
        if (!ctx.fill((int) Math.round(playerBullets.get(i).getX()),
          (int) Math.round(playerBullets.get(i).getY()), bulletChar)) {
          playerBullets.remove(i);
        }
      }

      if (score % killsPerSupply == 0 && healthSupply == null 
          && score != 0 && canHealthSupplySpawn) {
        healthSupply = new Entity((int) (Math.random() 
          * ctx.getWidth()), (int) (Math.random() 
          * ctx.getHeight()), -1, -1, -1);
      } else if (healthSupply != null) {
        ctx.fill(healthSupply.getX(), healthSupply.getY(), healthChar);
        if (player.getX() == healthSupply.getX() 
            && player.getY() == healthSupply.getY()) {
          player.takeDamage(-score);
          healthSupply = null;
          canHealthSupplySpawn = false;
        }
      }

      if (frame % framePerSpawn == 0 && currentFreeze == 0) {
        if (Math.random() < .33) {
          spawnX = 0;
          spawnY = (int) (Math.random() * ctx.getHeight());
        } else if (Math.random() < .5) {
          spawnX = ctx.getWidth() - 1;
          spawnY = (int) (int) (Math.random() * ctx.getHeight());
        } else {
          spawnX = (int) (Math.random() * ctx.getWidth());
          spawnY = 0;
        }
        if (ctx.getChar(spawnX, spawnY, '!') == ' ') {
          enemies.add(new Entity(spawnX, spawnY,
            score / killsPerDifficultyIncrement + 1,
            score / killsPerDifficultyIncrement + 1, 20));
        }
      }

      for (int i = 0; i < enemyBullets.size(); i++) {
        enemyBullets.get(i).update();
        if (!ctx.fill((int) Math.round(enemyBullets.get(i).getX()),
          (int) Math.round(enemyBullets.get(i).getY()), bulletChar)) {
          enemyBullets.get(i).getOwner().setShootPex(true);
          enemyBullets.remove(i);
        }
      }

      for (int i = 0; i < enemies.size(); i++) {
        if (dist(enemies.get(i).getX(), enemies.get(i).getY(),
            player.getX(), player.getY()) <= enemies.get(i).getRange()) {
          if (enemies.get(i).canShoot() && currentFreeze == 0) {
            enemyBullets.add(enemies.get(i).shoot(player.getX(), player.getY()));
            enemies.get(i).setShootPex(false);
          }
        } else if (frame % (msEnemyMovement * FPS / 1000) == 0 
            && currentFreeze == 0) {
          if (Math.abs(enemies.get(i).getX() - player.getX()) 
              > Math.abs(enemies.get(i).getY() - player.getY())) {
            if (ctx.getChar(enemies.get(i).getX() + (int) 
                Math.signum(player.getX() - enemies.get(i).getX()),
                enemies.get(i).getY(), '!') == ' ') {
              enemies.get(i).step((int) Math.signum(player.getX()
                - enemies.get(i).getX()), 0);
            }
          } else if (ctx.getChar(enemies.get(i).getX(),
              enemies.get(i).getY() + (int) Math.signum(
                player.getY() - enemies.get(i).getY()), '!') == ' ') {
            enemies.get(i).step(0, (int) Math.signum(player.getY()
              - enemies.get(i).getY()));
          }
        }

        for (int j = 0; j < playerBullets.size(); j++) {
          if ((int) (playerBullets.get(j).getX()) == enemies.get(i).getX()
              && (int) (playerBullets.get(j).getY()) == enemies.get(i).getY()
              || 1 + (int) (playerBullets.get(j).getX()) == enemies.get(i).getX()
              && 1 + (int) (playerBullets.get(j).getY()) == enemies.get(i).getY()) {
            enemies.get(i).takeDamage(playerBullets.get(j).getDMG());
            playerBullets.remove(j);
          }
        }

        if (!enemies.get(i).isAlive()) {
          dying.put(enemies.get(i), frame);
          enemies.remove(enemies.get(i));
          score++;
          msSpawnRate = (int) ((double) msSpawnRate * .99);
          framePerSpawn = msSpawnRate * FPS / 1000;
          canHealthSupplySpawn = true;
        } else if (!ctx.fill(enemies.get(i).getX(), enemies.get(i).getY(), enemyChar)) {
          enemies.remove(i);
        }
      }

      for (int i = 0; i < enemyBullets.size(); i++) {
        if ((int) (enemyBullets.get(i).getX()) == player.getX()
            && (int) (enemyBullets.get(i).getY()) == player.getY()) {
          player.takeDamage(enemyBullets.get(i).getDMG());
          enemyBullets.get(i).getOwner().setShootPex(true);
          enemyBullets.remove(i);
        } else if (!ctx.fill((int) Math.round(enemyBullets.get(i).getX()), 
            (int) Math.round(enemyBullets.get(i).getY()), bulletChar)) {
          enemyBullets.get(i).getOwner().setShootPex(true);
          enemyBullets.remove(i);
        }
      }

      iterator = dying.entrySet().iterator();
      while (iterator.hasNext()) {
        Map.Entry<Entity, Integer> entry = iterator.next();
        if (msDeathAnimation * FPS / 1000 != frame - entry.getValue()) {
          ctx.fill(entry.getKey().getX(), entry.getKey().getY(), dyingEnemy);
        } else {
          iterator.remove();
        }
      }

      if (!player.isAlive()) {
        break;
      } else {
        ctx.fill(player.getX(), player.getY(), playerChar);
      }

      if (freeze != null) {
        if (player.getX() == freeze.getX() && player.getY() == freeze.getY()) {
          freeze = null;
          currentFreeze += frameFreezingTime;
        } else {
          ctx.fill(freeze.getX(), freeze.getY(), freezeChar);
        }
      }

      ctx.fill((int) Math.round(shellRatio * aimDistance 
        * Math.cos(aimAngle) + player.getX()), (int) Math.round(aimDistance 
        * Math.sin(aimAngle) + player.getY()), aimChar);
      ctx.setSpecialCell(player.getX(), player.getY());
      ctx.draw();
      System.out.print("\u001b[34m" + " ".repeat(width / 3) + healthChar 
        + " x" + player.getHealth() + " ".repeat(width / 3)
        + scoreChar + " x" + score + "\u001b[0m" + "\r\n");
      wait(1000 / FPS);
    }
  }

  public int getScore() {
    return score;
  }

  private static double dist(int x1, int y1, int x2, int y2) {
    return Math.sqrt((x1 - x2) * (x1 - x2) + (y1 * 2 - y2 * 2) * (y1 * 2 - y2 * 2));
  }

  private static void wait(int ms) {
    try {
      Thread.sleep(ms);
    } catch (InterruptedException e) {}
  }
}
