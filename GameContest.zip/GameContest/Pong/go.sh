#!/bin/bash
stty raw
java Pong
stty -raw
