/**
Questo programma e' un gioco simile a pong.

@author Gioele Zanetti
@author Dennis Donofrio
@version 03.06.2020
*/

import java.io.*;

public class Pong{

	public static void main(String[] args){
		int scelta = 0;
		while(scelta < 10){
			try{
				while(scelta != 4){
					scelta = 0;
					clearShell();
					stampaMenu();
					while(scelta == 0){
						scelta = muoviRacchette('c', 'r', 'd', 'p');
						if(scelta == 1){
							stampaComandi();
							while(System.in.available() < 1){}
						}else if(scelta == 2){
							stampaRegole();
							while(System.in.available() < 1){}
						}else if(scelta == 3){
							stampaDiritti();
							while(System.in.available() < 1){}
						}
					}
				}
				int velocita = 0;
				stampaDifficolta();
				while(velocita == 0){
					int difficolta = muoviRacchette('1', '2', '3', '*');
					if(difficolta == 1){
						velocita = 150;
					}else if(difficolta == 2){
						velocita = 100;
					}else if(difficolta == 3){
						velocita = 65;
					}
				}
				int pg1 = 0;
				int pg2 = 0;
				while(pg1 < 3 && pg2 < 3){
					try{Thread.sleep(1000);}catch(InterruptedException ie){}
					clearShell();
					int n1 = 0;
					int n2 = 0;
					int orizzontale = muoviPallina();
					int spostaX = 0;
					int spostaY = 0;
					boolean punto = true;
					while(orizzontale == 0){
						orizzontale = muoviPallina();
					}
					int verticale = muoviPallina();
					stampaArena(0,0,0,0,pg1,pg2);
					while(punto){
						try{Thread.sleep(velocita);}catch(InterruptedException ie){}
						int posRak = muoviRacchette('w', 's', 'o', 'k');
						if(posRak == 1){
							n1 += 2;
						}else if(posRak == 2){
							n1 += -2;
						}else if(posRak == 3){
							n2 += 2;
						}else if(posRak == 4){
							n2 += -2;
						}
						if(n1 > 10){
							n1 = 10;
						}else if(n1 < -11){
							n1 = -11;
						}
						if(n2 > 10){
							n2 = 10;
						}else if(n2 < -11){
							n2 = -11;
						}
						clearShell();
						spostaX -= orizzontale;
						spostaY -= verticale;
					 	stampaArena(n1, n2, spostaY, spostaX, pg1, pg2);
						if(13 - spostaY == 1){
							verticale = 1;
							spostaY -= verticale;
					    	}else if(12 - spostaY == 24){
							verticale = -1;
							spostaY -= verticale;
						}else if(40 - spostaX == 8 && 12 - spostaY <=13-n1 && 12 - spostaY >= 10 - n1){
							orizzontale = 1;
							verticale = muoviPallina();
							spostaX -= orizzontale;
							spostaY -= verticale;
						}else if(40 - spostaX == 71 && 12 - spostaY <= 13 - n2 && 12 - spostaY >= 10 - n2){
							orizzontale = -1;
							verticale = muoviPallina();
							spostaX -= orizzontale;
							spostaY -= verticale;
						}else if(40 - spostaX < 6){
							pg2 += 1;
							punto = false;
						}else if(40 - spostaX > 74){
							pg1 += 1;
							punto = false;
					 	}
					}
				}
				clearShell();
				if(pg1 < pg2){
					System.out.println("\n\n\t\t Player 2 Won");
					System.out.println("\n\n\t\t Player 1 Lose\n\n\r");
				}else{
					System.out.println("\n\n\t\t Player 1 Won");
					System.out.println("\n\n\t\t Player 2 Lose\n\n\r");
				}
				System.out.print("Premere p per continuare a giocare: ");
				while(System.in.available() < 1){}
				scelta = muoviRacchette('p', '*', '*', '*');
				if(scelta != 1){
					scelta = 11;
				}
			}catch(IOException ioe){
			    System.out.println("tastiera non funzionante");
			}
		}
	}

	public static int muoviPallina(){
		int numeroCasuale = -1 + (int)(Math.random() * 3);
		return numeroCasuale;
	}

	public static int muoviRacchette(char c1, char c2, char c3, char c4) throws IOException{
		if(System.in.available() > 0){
			int cmd = System.in.read();
			if(cmd == c1){
				return 1;
			}else if(cmd == c2){
				return 2;
			}else if(cmd == c3){
				return 3;
			}else if(cmd == c4){
				return 4;
			}else if(cmd == 'q'){
				clearShell();
				System.exit(0);
			}
		}
		return 0;
	}

	public static void stampaArena(int destra, int sinistra, int yPallina, int xPallina, int pg1, int pg2){
		stampaBordoOrizzontale('\u250f','\u2513');
		for(int i=0;i<25;i++){
			for(int j=0;j<80;j++){
				if(j==0||j==79){
					System.out.print('\u2503');
				}else if(j==7&&i<=13-destra&&i>=10-destra){
					System.out.print('\u2551');
				}else if(j==73&&i<=13-sinistra&&i>=10-sinistra){
					System.out.print('\u2551');
				}else if(i == 12 - yPallina && j == 40 - xPallina){
					System.out.print("\u001b[93m");
					System.out.print('\u25ef');
					System.out.print("\u001b[37m");
				}else{
					System.out.print(" ");
				}
			}
			System.out.print("\r\n");
		}
		stampaBordoOrizzontale('\u2517','\u251b');
		System.out.println("G1 => " + pg1 + "				<-- PUNTEGGIO -->			" + pg2 + " <= G2\r\n");
	}

	public static void stampaMenu(){
		stampaLogo();
		for(int i = 0; i < 5; i++){
			System.out.print("\r\n");
		}
		System.out.println("Per giocare premere p\r");
		System.out.println("Per vedere i comandi premere c\r");
		System.out.println("Per vedere le regole premere r\r");
		System.out.println("Per vedere i crediti premere d\r");
		System.out.println("Per uscire premere q\r");
	}

	public static void stampaBordoOrizzontale(char c1, char c2){
		System.out.print(c1);
		for(int i=0;i<78;i++){
			System.out.print('\u2501');
		}
		System.out.print(c2);
		System.out.print("\r\n");
	}

	public static void clearShell(){
		System.out.print("\033[H\033[2J");
    		System.out.flush();
	}

	public static void stampaComandi(){
		clearShell();
		stampaLogo();
		System.out.println("Comandi\r");
		for(int i = 0; i < 5; i++){
			System.out.print("\n\r");
		}
		System.out.println("Giocatore 1 (sx):\r");
		System.out.println("\t W ==> Su\r");
		System.out.println("\t S ==> Giu\r");
		System.out.println("\r");
		System.out.println("Giocatore 2 (dx):\r");
		System.out.println("\t O ==> Su\r");
		System.out.println("\t K ==> Giu\r\n");
		System.out.println("Premere P per giocare\r");
		System.out.println("Premere un altro tasto per tornare al menu\r");
	}

	public static void stampaRegole(){
		clearShell();
		stampaLogo();
		System.out.println("Regole\r\n\n\n\n\n");
		System.out.println("1) Non e' consigliato muoversi insieme\r");
		System.out.println("2) Lo scopo e' arrivare a 3 punti,\n\r   il primo che arriva a 3 punti vince\r\n");
		System.out.println("Premere P per giocare\r");
                System.out.println("Premere un altro tasto per tornare al menu\r");
	}

	public static void stampaDiritti(){
		clearShell();
		stampaLogo();
		System.out.println("Diritti\r\n\n\n\n\n");
		System.out.println("Il gioco e' open source e gratuito\r");
		System.out.println("Programmatori: Gioele Zanetti & Dennis Donofrio\r\n");
		System.out.println("Premere P per giocare\r");
                System.out.println("Premere un altro tasto per tornare al menu\r");
	}

	public static void stampaDifficolta(){
		clearShell();
		stampaLogo();
		System.out.println("Difficolta'\r\n\n\n\n\n");
		System.out.println("Difficolta' 1 ==> Easy\r");
		System.out.println("Difficolta' 2 ==> Normal\r");
		System.out.println("Difficolta' 3 ==> Hard\r");
		System.out.print("Inserire la difficolta' desiderata: ");
	}

	public static void stampaLogo(){
		System.out.print("\u250c\u2500\u2500\u2500\u2510\u250c\u2500\u2500\u2500\u2510\u250c\u2500\u252c\u2510\u250c\u2500\u2500\u2500\u2510\n\r");
		System.out.print("\u2502\u250c\u2500\u2510\u2502\u2502\u250c\u2500\u2510\u2502\u2502\u2502\u2502\u2502\u2502\u250c\u2500\u2500\u2518\n\r");
		System.out.print("\u2502\u2514\u2500\u2518\u2502\u2502\u2502 \u2502\u2502\u2502\u2502\u2502\u2502\u2502\u2502\u250c\u2500\u2510\n\r");
		System.out.print("\u2502\u250c\u2500\u2500\u2518\u2502\u2502 \u2502\u2502\u2502\u2502\u2502\u2502\u2502\u2502\u2514\u2510\u2502\n\r");
		System.out.print("\u2502\u2502   \u2502\u2514\u2500\u2518\u2502\u2502\u2502\u2502\u2502\u2502\u2514\u2500\u2518\u2502\n\r");
		System.out.print("\u2514\u2518   \u2514\u2500\u2500\u2500\u2518\u2514\u2534\u2500\u2518\u2514\u2500\u2500\u2500\u2518\n\r");
	}
}
