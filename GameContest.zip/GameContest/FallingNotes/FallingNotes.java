import java.io.IOException;

/**
*minigioco simile a 'guitar hero'
*@author Cloe Sava
*@version 21.06.2020
*/
public class FallingNotes {
        public static void main(String[] args) {
            try {
                    // pagina iniziale
                    home();
            
                    
            } catch (NumberFormatException er){
                System.out.println("Inserire un numero intero (int)!!!");
            } 
        }
        public static void home(){
            try{
                String[][] home = {
                    {"\r\n"},
                    {" ______________________________________________________________________ "},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|       GGGGGGG          AAAAAAA      MMM         MMM   EEEEEEEEEEEEEE |"},
                    {"|     GG       GG       A       A     M  M       M  M   E              |"},
                    {"|   GG           GG    A         A    M   M     M   M   E              |"},
                    {"|  G               G   A         A    M   M     M   M   E              |"},
                    {"| G                    A         A    M    M   M    M   E              |"},
                    {"| G                    A         A    M    M   M    M   E              |"},
                    {"| G     GGGGGGGGGGG    AAAAAAAAAAA    M     M M     M   EEEEEEEEE      |"},
                    {"| G                G   A         A    M      M      M   E              |"},
                    {"| G                G   A         A    M             M   E              |"},
                    {"|  G              G    A         A    M             M   E              |"},
                    {"|   GG          GG     A         A    M             M   E              |"},
                    {"|     GG      GG       A         A    M             M   E              |"},
                    {"|       GGGGGG         A         A    M             M   EEEEEEEEEEEEEE |"},
                    {"|                                                                      |"},
                    {"|                                  by                                  |"},
                    {"|                              Cloe & Pascale                          |"},
                    {"|                                                                      |"},
                    {"|                     .---------------------------.                    |"},
                    {"|                     |    s  =>   START  GAME    |                    |"},
                    {"|                     '---------------------------'                    |"},
                    {"|                     .---------------------------.                    |"},
                    {"|                     |    i  =>    GAME  INFO    |                    |"},
                    {"|                     '---------------------------'                    |"},
                    {"|                     .---------------------------.                    |"},
                    {"|                     |    c  =>     CRERITI      |                    |"},
                    {"|                     '---------------------------'                    |"},
                    {"|                                                                      |"},
                    {"|______________________________________________________________________|"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"}
                };
                String[][] home2 = {
                    {"\r\n"},
                    {" ______________________________________________________________________ "},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|       ggggggg          aaaaaaa      mmm         mmm   eeeeeeeeeeeeee |"},
                    {"|     gg       gg       a       a     m  m       m  m   e              |"},
                    {"|   gg           gg    a         a    m   m     m   m   e              |"},
                    {"|  g               g   a         a    m   m     m   m   e              |"},
                    {"| g                    a         a    m    m   m    m   e              |"},
                    {"| g                    a         a    m    m   m    m   e              |"},
                    {"| g     ggggggggggg    aaaaaaaaaaa    m     m m     m   eeeeeeeee      |"},
                    {"| g                g   a         a    m      m      m   e              |"},
                    {"| g                g   a         a    m             m   e              |"},
                    {"|  g              g    a         a    m             m   e              |"},
                    {"|   gg          gg     a         a    m             m   e              |"},
                    {"|     gg      gg       a         a    m             m   e              |"},
                    {"|       gggggg         a         a    m             m   eeeeeeeeeeeeee |"},
                    {"|                                                                      |"},
                    {"|                                  by                                  |"},
                    {"|                              Cloe & Pascale                          |"},
                    {"|                                                                      |"},
                    {"|                     .---------------------------.                    |"},
                    {"|                     |    s  =>   START  GAME    |                    |"},
                    {"|                     '---------------------------'                    |"},
                    {"|                     .---------------------------.                    |"},
                    {"|                     |    i  =>    GAME  INFO    |                    |"},
                    {"|                     '---------------------------'                    |"},
                    {"|                     .---------------------------.                    |"},
                    {"|                     |    c  =>     CRERITI      |                    |"},
                    {"|                     '---------------------------'                    |"},
                    {"|                                                                      |"},
                    {"|______________________________________________________________________|"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"}
                };
                boolean x = true; 
                int punteggio = 0;
                do{
                    int ms = 100;
                    stampa(home,ms);
                    stampa(home2,ms);
                    if(System.in.available() > 0){
                        int cmd = System.in.read();
                        if(cmd == 's'){
                            x = false;
                            game();
                        }else if(cmd == 'i'){
                            x = false;
                            info();
                        }else if(cmd == 'c'){
                            x = false;
                            crediti();
                        }else if(cmd == 'q'){
                            x = false;
                            goodbye(punteggio);
                        }
                    }
                }while(x);
                
            }catch(IOException e){}
                //  if(premi i){
                //      info();    
                //} else if(premi s){
                //      game();
                //}     
        }
        public static void game(){
            try{
                int punteggio = 0;
                String[][] campoGioco = {
                    {"\r\n"},
                    {" ______________________________________________________________________" },
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|''............''''''............''''''............''''''............''|"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|______________________________________________________________________|"},
                    {"   ...........        ...........       ...........       ...........   "},
                    {"  |     s     |      |     d     |     |     f     |     |     g     |  "},
                    {"   '''''''''''        '''''''''''       '''''''''''       '''''''''''   "},
                    {"\r\n"}, 
                    {"\r\n"},
                    {"\r\n"}
                };
                String[][] s1 = new String[campoGioco.length][1];
                String[][] s2 = new String[campoGioco.length][1];
                String[][] s3 = new String[campoGioco.length][1];
                String[][] s4 = new String[campoGioco.length][1];
                int randomContatore = 0;
                int randomPosizione = (int)(Math.random() * 3 + 1);
                int contatore = 0;
                int contaPerTempo = 0;
                int[][] posizioneNota = new int[campoGioco.length][1];
                int[][] posizione = new int[campoGioco.length][1];
                String nota = "||||||||||||";
                boolean stopGame = true;
                boolean x = false;
                int ms = 80; 
                for(int i = 0; i < posizioneNota.length; i++){
                    posizioneNota[i][0] = 0;
                }
                do{
                    if(contaPerTempo > 50 && ms > 10){
                        ms = ms - 5;
                        contaPerTempo = 0;
                    }
                    // aggiungo un nota v
                    if(contatore >= randomContatore){
                        contatore = 0;
                        randomContatore = (int)(Math.random() * 10 + 10);
                        randomPosizione = (int)(Math.random() * 4 + 1);
                        for(int i = 0; i < posizioneNota.length ; i++){
                            if(posizioneNota[i][0] == 0){
                                posizioneNota[i][0] = 1;
                                posizione[i][0] = randomPosizione;
                                i = posizioneNota.length + 10;
                            }
                        }
                    }
                    // svuoto il campo da gioco v
                    for(int i = 0; i < s1.length; i++){
                        s1[i][0] = "            ";
                        s2[i][0] = "            ";
                        s3[i][0] = "            ";
                        s4[i][0] = "            ";
                    }
                    // riscrivo le note nella giusta posizione... v
                    for(int i = 0; i < s1.length; i++){
                        if(posizioneNota[i][0] != 0){
                            if(posizione[i][0] == 1){
                                if(posizioneNota[i][0] >= 1){
                                    s1[posizioneNota[i][0]][0] = nota;
                                }
                                if(posizioneNota[i][0] >= 2){
                                    s1[posizioneNota[i][0] - 1][0] = nota;
                                }
                                if(posizioneNota[i][0] > 2){
                                    s1[posizioneNota[i][0] - 2][0] = nota;
                                }
                            }else if(posizione[i][0] == 2){
                                if(posizioneNota[i][0] >= 1){
                                    s2[posizioneNota[i][0]][0] = nota;
                                }
                                if(posizioneNota[i][0] >= 2){
                                    s2[posizioneNota[i][0] - 1][0] = nota;
                                }
                                if(posizioneNota[i][0] > 2){
                                    s2[posizioneNota[i][0] - 2][0] = nota;
                                }
                            }else if(posizione[i][0] == 3){
                                if(posizioneNota[i][0] >= 1){
                                    s3[posizioneNota[i][0]][0] = nota;
                                }
                                if(posizioneNota[i][0] >= 2){
                                    s3[posizioneNota[i][0] - 1][0] = nota;
                                }
                                if(posizioneNota[i][0] > 2){
                                    s3[posizioneNota[i][0] - 2][0] = nota;
                                }
                            }else if(posizione[i][0] == 4){
                                if(posizioneNota[i][0] >= 1){
                                    s4[posizioneNota[i][0]][0] = nota;
                                }
                                if(posizioneNota[i][0] >= 2){
                                    s4[posizioneNota[i][0] - 1][0] = nota;
                                }
                                if(posizioneNota[i][0] > 2){
                                    s4[posizioneNota[i][0] - 2][0] = nota;
                                }
                            }
                        }
                    }
                    // "ricarico" il campo da gioco v
                    int j = 1;
                    for(int i = 2; i < s1.length -1; i++){
                        if(i != 31 && i < 34){
                            if(punteggio < 10){
                                campoGioco[38][0] = "   punteggio = "+ punteggio;
                            }
                            campoGioco[i][0] = "|  " + s1[j][0] + "      " + s2[j][0] + "      " + s3[j][0] + "      " + s4[j][0] + "  |";
                        }
                        j++;
                    }
                    // stampo v
                    stampa(campoGioco, ms);

                    // incremento di 1
                    for(int i = 0; i < posizioneNota.length;i++){
                        if(posizioneNota[i][0] != 0){
                            if(posizioneNota[i][0] <= 33){
                                posizioneNota[i][0] = posizioneNota[i][0] + 1; 
                            }else{
                                posizioneNota[i][0] = 0;
                            }
                        }
                    }
                    contatore++;
                    contaPerTempo++;
                    if(System.in.available() > 0){
                        int cmd = System.in.read();
                        if(cmd == 's'){
                            if(s1[31][0] == nota || s1[32][0] == nota || s1[33][0] == nota){
                                punteggio++;
                            }else{
                                punteggio--;
                            }
                        }else if(cmd == 'd'){
                            if(s2[31][0] == nota || s2[32][0] == nota || s2[33][0] == nota){
                                punteggio++;
                            }else{
                                punteggio--;
                            }
                        }else if(cmd == 'f'){
                            if(s3[31][0] == nota || s3[32][0] == nota || s3[33][0] == nota){
                                punteggio++;
                            }else{
                                punteggio--;
                            }
                        }else if(cmd == 'g'){
                            if(s4[31][0] == nota || s4[32][0] == nota || s4[33][0] == nota){
                                punteggio++;
                            }else{
                                punteggio--;
                            }
                        }else if(cmd == 'q'){
                            stopGame = false;
                            goodbye(punteggio);
                        }
                    }
                    if(punteggio < -10){
                        stopGame = false;
                        gameover();
                    }
                }while(stopGame); 
            }catch(IOException e){

            }
        }
        public static void info(){
            try{
                String[][] info = {
                    {"\r\n"},
                    {" ______________________________________________________________________" },
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|              INFORMAZIONI VARIE RIGUARDANTI IL GIOCO                 |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|   Questo gioco consiste nel riuscire a prendere il maggior numero    |"},
                    {"|   di note, ad ogni nota presa si guadagna un punto invece se si      |"},
                    {"|   sbaglia tempismo se ne perde uno.                                  |"},
                    {"|                                                                      |"},
                    {"|   Il gioco termina se si arriva ad un punteggio di \"-10\".            |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|   Per uscire dal gioco basta premere 'q'.                            |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|   Comandi:                                                           |"},
                    {"|                                                                      |"},
                    {"|   Per uscire dal gioco in qualsiasi momento premere 'q' .            |"},
                    {"|   I pulsanti per le note sono 's' 'd' 'f' 'g' .                      |"},
                    {"|   Il resto dei pulsanti sono segnati.                                |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"| .------.                                                             |"},
                    {"| | <= r |                                                             |"},
                    {"| '------'                                                             |"},
                    {"|______________________________________________________________________|"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"}
                };
                int ms = 100;
                boolean i = true;
                int punteggio = 0;
                do{
                    stampa(info, ms);
                    if(System.in.available() > 0){
                        int cmd = System.in.read();
                        if(cmd == 'r'){
                            i = false;
                            home();
                        }
                        if(cmd == 'q'){
                            i = false;
                            goodbye(punteggio);
                        }
                        
                    }
                }while(i);
            } catch(IOException e){

            }
        }
        
        public static void crediti(){
            try{
                String[][] info = {
                    {"\r\n"},
                    {" ______________________________________________________________________" },
                    {"|                                                                      |"},
                    {"|                              Produttori:                             |"},
                    {"|                                                                      |"},
                    {"|                          Pascale  Alessandro                         |"},
                    {"|                              Sava  Cloe                              |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                          Ingenieri di Gioco:                         |"},
                    {"|                                                                      |"},
                    {"|                          Pascale  Alessandro                         |"},
                    {"|                              Sava  Cloe                              |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                           Disegni & Desing:                          |"},
                    {"|                                                                      |"},
                    {"|                          Pascale  Alessandro                         |"},
                    {"|                              Sava  Cloe                              |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                          Designer del Gioco:                         |"},
                    {"|                                                                      |"},
                    {"|                          Pascale Alessandro                          |"},
                    {"|                              Sava  Cloe                              |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                          Direttore del Gioco:                        |"},
                    {"|                                                                      |"},
                    {"|                              Sava  Cloe                              |"},
                    {"|                                                                      |"},
                    {"| .------.                                               .-----------. |"},
                    {"| | <= r |                                               | other = o | |"},
                    {"| '------'                                               '-----------' |"},
                    {"|______________________________________________________________________|"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"}
                };
                int ms = 100;
                boolean i = true;
                int punteggio = 0;
                do{
                    stampa(info, ms);
                    if(System.in.available() > 0){
                        int cmd = System.in.read();
                        if(cmd == 'r'){
                            i = false;
                            home();
                        }
                        if(cmd == 'q'){
                            i = false;
                            goodbye(punteggio);
                        }
                        if(cmd == 'o'){
                            i = false;
                            crediti2();
                        }
                        
                    }
                }while(i);
            } catch(IOException e){

            }
        }public static void crediti2(){
            try{
                String[][] info = {
                    {"\r\n"},
                    {" ______________________________________________________________________" },
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                          Direttori progetto:                         |"},
                    {"|                                                                      |"},
                    {"|                             Muggiasca Luca                           |"},
                    {"|                            Albertini Andrea                          |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                          Pascale Alessandro                          |"},
                    {"|                              Sava  Cloe                              |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                          Generale degli affari:                      |"},
                    {"|                                                                      |"},
                    {"|                          Pascale Alessandro                          |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                         Operazioni nel gioco:                        |"},
                    {"|                                                                      |"},
                    {"|                          Pascale Alessandro                          |"},
                    {"|                              Sava  Cloe                              |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"|                                                                      |"},
                    {"| .------.                                              .------------. |"},
                    {"| | <= r |                                              | before = b | |"},
                    {"| '------'                                              '------------' |"},
                    {"|______________________________________________________________________|"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"},
                    {"\r\n"}
                };
                int ms = 100;
                boolean i = true;
                int punteggio = 0;
                do{
                    stampa(info, ms);
                    if(System.in.available() > 0){
                        int cmd = System.in.read();
                        if(cmd == 'r'){
                            i = false;
                            home();
                        }
                        if(cmd == 'q'){
                            i = false;
                            goodbye(punteggio);
                        }
                        if(cmd == 'b'){
                            i = false;
                            crediti();
                        }
                        
                    }
                }while(i);
            } catch(IOException e){

            }
        }
        public static void goodbye(int punteggio){
            String[][] goodbye = {
                {"\r\n"},
                {" ______________________________________________________________________" },
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"| .-------. .-------. .-------. .---.     .-----.  .       . .-------- |"},
                {"| |       ' |       | |       | |    '.   |      |  \\     /  |         |"},
                {"| |         |       | |       | |      '. |      .   \\   /   |         |"},
                {"| |   ----. |       | |       | |       | |   --'     \\ /    |------   |"},
                {"| |       | |       | |       | |       . |      '.    |     |         |"},
                {"| |       | |       | |       | |     .'  |       |    |     |         |"},
                {"| '-------' '-------' '-------' '----'    '------'     '     '-------- |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|______________________________________________________________________|"},
                {"\r\n"},
                {"\r\n"},
                {"\r\n"},
                {"\r\n"},
                {"\r\n"},
                {"\r\n"}
            };
            if(punteggio != 0){
                goodbye[37][0] = "                             punteggio = " + punteggio + "                             ";
            }
            for(int i = 0; i < goodbye.length; i++){
                System.out.print(goodbye[i][0] + "\r\n");
            }
        }
        
        public static void gameover(){
            String[][] gameover = {
                {"\r\n"},
                {" ______________________________________________________________________" },
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|  .-----. .-----. .-. .-. .------    .-----. .     . .------ .----_   |"},
                {"|  |     ' |     | |  |  | |          |     | |     | |       |     .  |"},
                {"|  |       |     | |  |  | |          |     | |     | |       | ___-   |"},
                {"|  |  ---. |_____| |  |  | |----      |     |  |   |  |----   |  \\     |"},
                {"|  |     | |     | |     | |          |     |   | |   |       |   \\    |"},
                {"|  '-----' '     ' '     ' '------    '-----'    .    '------ .    .   |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|                                                                      |"},
                {"|______________________________________________________________________|"},
                {"\r\n"},
                {"\r\n"},
                {"\r\n"},
                {"\r\n"},
                {"\r\n"},
                {"\r\n"}
            };
            for(int i = 0; i < gameover.length; i++){
                System.out.print(gameover[i][0] + "\r\n");
            }
        }
        public static void stampa(String[][] matrice, int ms){
            try{
                    for(int i = 0; i < matrice.length; i++){
                        System.out.print(matrice[i][0] + "\r\n");
                    }
                        Thread.sleep(ms);
                //  if(premi i){
                //      info();    
                //} else if(premi s){
                //      game();
                //}     
            } catch (NumberFormatException er){
                System.out.println("Inserire un numero intero (int)!!!");
            } catch (InterruptedException ex) {
            }
        }
    }
