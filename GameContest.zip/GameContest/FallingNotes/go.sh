#!/bin/bash
stty raw
java FallingNotes.java
stty -raw
