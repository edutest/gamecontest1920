/**
* il programma ricrea il gioco "doodle jump" in versione semplificata
*
* @authors Andrea Curti
* @authors Emanuele Carpentieri
* @version 10.06.2020
*/

import java.io.*;

public class Gioco{
    
	static int colonneIsole = 40;
	static int righeIsole = 30;
	static char[][] islands = new char[righeIsole][colonneIsole];
	static char player = '\u25AE';
	static int xPlayer = colonneIsole/2 - 1;
	static int yPlayer = righeIsole - 2;
	static int volte = 0;
	static char corrente = ' '; 
	static char[] punti = new char[7];
	static int punteggio = 0;    
	static long start = 0;
	public static void main (String[] args){
		InputStreamReader input = new InputStreamReader(System.in);
		BufferedReader tastiera = new BufferedReader(input);
		String testo = "";
		try{
			System.out.print("\033[H\033[2J");
	                System.out.flush();
			System.out.println("\r");
			System.out.println("              MENU \r");
			System.out.println("\r");
			System.out.println("Premere il tasto s per giocare \r");
			System.out.println("\r");
			System.out.println("Premere il tasto h per i comandi \r");
			System.out.println("\r");
			System.out.println("Premere il tasto c per i crediti \r");
			System.out.println("\r");
			System.out.println("Premere il tasto q per uscire \r");
			System.out.println("\r");
			System.out.print("Opzione: ");
			testo = tastiera.readLine();
			System.out.println("\r");
			System.out.print("\033[H\033[2J");
	                System.out.flush();
			if(testo.equals("s")){
				start = System.currentTimeMillis(); 
				char barra = '-';
				punti[0] = 'P';
				punti[1] = 'u';
				punti[2] = 'n';
				punti[3] = 't';
				punti[4] = 'i';
				punti[5] = ':';
				punti[6] = ' ';
				for(int i = 0; i < islands.length; i++){
					for(int j = 0; j < islands[i].length; j++){
						islands[i][j] = ' ';
					}
				}
				for(int i = 0; i < colonneIsole-1; i++){
					islands[0][i] = '*';
					islands[righeIsole-1][i] = '*';
				}
				for(int j = 0; j < righeIsole-1; j++){
					islands[j][0] = '*';
					islands[j][colonneIsole-1] = '*';
                		}
                		islands[righeIsole-1][colonneIsole-1] = '*';
                		islands[yPlayer][xPlayer] = player;
                		for(int i = 1; i < (islands.length - 2); i++){	
					for(int j = 0; j < 2; j = j){
						int indiceRandom = (int)(Math.random() * ((colonneIsole - 1) - 0 + 1)) + 0;
						if((indiceRandom > 1)&&(indiceRandom < colonneIsole - 2)){
							if(islands[i][indiceRandom-2] != barra){
								islands[i][indiceRandom] = barra;
                                				islands[i][indiceRandom-1] = barra;
								j++;
							} 
						}
					}
				}
				for(int i = 0; i < islands.length; i++){
					for(int j = 0; j < islands[i].length; j++){
							System.out.print(islands[i][j]);
					}
					System.out.println("\r");
				}
				for(int i = 0; i < punti.length; i++){
					System.out.print(punti[i]);
				}
				System.out.println(Integer.toString(punteggio)+"\r");
                		movimento(islands);
			}else if(testo.equals("h")){
				System.out.println("\r");
				System.out.println("             Su = w \r");
				System.out.println("\r");
				System.out.println("\r");
				System.out.println("            Giu = s \r");
				System.out.println("\r");
				System.out.println("\r");
				System.out.println("           Destra = d \r");
				System.out.println("\r");
				System.out.println("\r");
				System.out.println("          Sinistra = a \r");
				System.out.println("\r");
				
			}else if(testo.equals("c")){
				System.out.println("\r");
				System.out.println("             Crediti: \r");
				System.out.println("\r");
				System.out.println("           Andrea Curti \r");
				System.out.println("\r");
				System.out.println("       Emanuele Carpentieri \r");
				System.out.println("\r");
				System.out.println("     Progetto gioco java 2020 \r");
				System.out.println("\r");
			}else if(testo.equals("q")){
				System.exit(0);
			}else{
				System.out.println("\r");
				System.out.println("Tasto non trovato \r");
				System.out.println("\r");
			}
		}catch(IOException e){
			System.out.println("\r");
			System.out.println("Error");
			System.out.println("\r");
		}
	}
    
    public static void movimento(char[][] islands){
        boolean gameover = false;
        try{
            while(gameover == false){
            	if(System.in.available() > 0){
                	int cmd = System.in.read();
                	if(cmd == 'w'){
                        	spostaSu(islands);
                 	}else if(cmd == 'a'){
				spostaSinistra(islands);
                	}else if(cmd == 'd'){ 
				spostaDestra(islands);                       
 			}else if(cmd == 's'){
				spostaGiu(islands);
	               	}else if(cmd == 'q'){
				System.exit(0);
			}
            	}
	   }
        }catch(IOException e){
		System.out.println("Error \r");
        }
    }
    
	public static void clearScreen(){
		System.out.print("\033[H\033[2J");
		System.out.flush();
		int rimanenti = 0;
		for(int i = 0; i < islands.length; i++){
			for(int j = 0; j < islands[i].length; j++){
				if(islands[i][j] == '-'){
					rimanenti++;
				}
			}
		}
		if(rimanenti == 0){
			long end = System.currentTimeMillis();
			long time = end - start;
			time = time/1000;
			System.out.print("\033[H\033[2J");
			System.out.flush();
			System.out.println("\r");
			System.out.println("     TEMPO IMPIEGATO: "+time+" secondi \r");
			System.out.println("\r");
			System.exit(0);
		}
	}
    
	public static void spostaSu(char[][] islands){
		for(int i = 0; i < 1; i++){
	        	clearScreen();
			if(yPlayer > 1){
				if(corrente == ' '){
		               		islands[yPlayer][xPlayer] = ' ';
       		         		yPlayer--;
					corrente = islands[yPlayer][xPlayer];
       	        	 		islands[yPlayer][xPlayer] = player;
				}else if(corrente == '-'){
					islands[yPlayer][xPlayer] = ' ';
					yPlayer--;
					punteggio++;
					corrente = islands[yPlayer][xPlayer];
					islands[yPlayer][xPlayer] = player;
				}
                	}else{
				islands[yPlayer][xPlayer] = player;
			}
			for(int ii = 0; ii < islands.length; ii++){
                                        for(int j = 0; j < islands[ii].length; j++){
                                                System.out.print(islands[ii][j]);
                                        }
                                        System.out.println("\r");
                                }
                                for(int ii = 0; ii < punti.length; ii++){
                                        System.out.print(punti[ii]);
                                }
                                System.out.println(Integer.toString(punteggio)+"\r");

                	try{
            	        	Thread.sleep(150);
                	}catch (InterruptedException ex) {
                	}
    		}
	}

	public static void spostaDestra(char[][] islands){
        	for(int i = 0; i < 1; i++){
        		clearScreen();
            		if(xPlayer < colonneIsole - 2){
				if(corrente == ' '){
                            		islands[yPlayer][xPlayer] = ' ';
                            		xPlayer++;
                            		corrente = islands[yPlayer][xPlayer];
                            		islands[yPlayer][xPlayer] = '\u25AE';
                        	}else if(corrente == '-'){
                        		islands[yPlayer][xPlayer] = ' ';
			  		xPlayer++;
					punteggio++;
					corrente = islands[yPlayer][xPlayer];
					islands[yPlayer][xPlayer] = '\u25AE';
                       		}
			}else{
                		islands[yPlayer][xPlayer] = player;
            		}
			for(int ii = 0; ii < islands.length; ii++){
                                        for(int j = 0; j < islands[ii].length; j++){
                                                System.out.print(islands[ii][j]);
                                        }
                                        System.out.println("\r");
                                }
                                for(int ii = 0; ii < punti.length; ii++){
                                        System.out.print(punti[ii]);
                                }
                                System.out.println(Integer.toString(punteggio)+"\r");

            		try{
                		Thread.sleep(150);
            		}catch (InterruptedException ex) {
            		}
    		}
        }
        public static void spostaSinistra(char[][] islands){
        	for(int i = 0; i < 1; i++){
        		clearScreen();
                	if(xPlayer > 1){
                    		if(corrente == ' '){
                        		islands[yPlayer][xPlayer] = ' ';
                        		xPlayer--;
                        		corrente = islands[yPlayer][xPlayer];
                        		islands[yPlayer][xPlayer] = '\u25AE';
                    		}else if(corrente == '-'){
					islands[yPlayer][xPlayer] = ' ';
                                        xPlayer--;
					punteggio++;
                                        corrente = islands[yPlayer][xPlayer];
                                        islands[yPlayer][xPlayer] = '\u25AE';
				}
                	}else{
				islands[yPlayer][xPlayer] = player;
                	}
			for(int ii = 0; ii < islands.length; ii++){
                                        for(int j = 0; j < islands[ii].length; j++){
                                                System.out.print(islands[ii][j]);
                                        }
                                        System.out.println("\r");
                                }
                                for(int ii = 0; ii < punti.length; ii++){
                                        System.out.print(punti[ii]);
                                }
                                System.out.println(Integer.toString(punteggio)+"\r");
                	try{
                    		Thread.sleep(150);
                	}catch(InterruptedException ex) {
                	}
            	}
        }

	public static void spostaGiu(char[][] islands){
                for(int i = 0; i < 1; i++){
                        clearScreen();
                        if(yPlayer < righeIsole - 2){
                                if(corrente == ' '){
                                        islands[yPlayer][xPlayer] = ' ';
                                        yPlayer++;
                                        corrente = islands[yPlayer][xPlayer];
                                        islands[yPlayer][xPlayer] = player;
                                }else if(corrente == '-'){
                                        islands[yPlayer][xPlayer] = ' ';
                                        yPlayer++;
                                        punteggio++;
                                        corrente = islands[yPlayer][xPlayer];
                                        islands[yPlayer][xPlayer] = player;
                                }
                        }else{
                                islands[yPlayer][xPlayer] = player;
                        }
			for(int ii = 0; ii < islands.length; ii++){
                                        for(int j = 0; j < islands[ii].length; j++){
                                                System.out.print(islands[ii][j]);
                                        }
                                        System.out.println("\r");
                                }
                                for(int ii = 0; ii < punti.length; ii++){
                                        System.out.print(punti[ii]);
                                }
                                System.out.println(Integer.toString(punteggio)+"\r");

                        try{
                                Thread.sleep(150);
                        }catch (InterruptedException ex) {
                        }
                }
        }
}








