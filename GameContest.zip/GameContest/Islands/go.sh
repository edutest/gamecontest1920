#!/bin/bash
stty raw
java Gioco
stty -raw
