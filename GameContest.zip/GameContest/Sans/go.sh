#!/bin/bash
stty raw
java Sans
stty -raw
