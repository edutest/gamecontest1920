/**
* Abbiamo realizzato un videogioco 2d di Undertale versione semplificata,
* abbiamo messo boss di questo videogame. Questo gioco consiste di affrontare
* contro il boss attraverso il suo minigioco. Hai disposizione da 1 a 5 cure
* a dipendenza della difficolta' selezionata.
* Ci sono 2 turni, ovvero il turno di Boss (Sans) e turno dell'utente. 
* Il turno del boss, nel campo di testo c'e' un minigioco e tu devi riuscire a
* non subire i danni, la durata di questo turno e' 15 secondi. Dopo
* c'e' il turno dell'utente devi scegliere se attaccare o curarti (ricordando
* che hai un limite di disposizione delle cure). Nel menu puoi entrare nella
* sezione comandi per vedere le istruzioni dei comandi, poi puoi entrare anche
* nella sezione difficolta' che puoi impostare le difficolta', che cambia il 
* numero di cure e le vite.
* Dimensione terminale consigliata: 24x80
* @author Pasquini e Fumasoli
* @version 04.06.2020
*/

import java.io.*;
import static org.alb.util.AnsiEscapes.*;


public class Sans{

	public static void interfacciaSuperiore(int vitaSans, int vitaSansAttuale, boolean occhioDestro){
		setForegroundColor(COLOR_BLACK);
		System.out.print("Vita Sans: "+vitaSansAttuale+"/"+vitaSans+'\r'+'\n');
		System.out.print("    "); //interfaccia prova di Sans
		for(int i = 0; i < 11; i++){
			System.out.print('\u2588');
		}
		System.out.print("\r\n");
		System.out.print("   "+'\u2588'+'\u2588'+"         "+'\u2588'+'\u2588'+"\r\n");
		System.out.print("  "+'\u2588'+"   _     _   "+'\u2588'+"\r\n");
		System.out.print(" "+'\u2588'+"   "+'\u2588'+"_"+'\u2588'+"   "+'\u2588');
		if(occhioDestro){
			setForegroundColor(COLOR_BLUE);
			System.out.print('\u2588');
			setForegroundColor(COLOR_BLACK);
		}else{
			System.out.print("_");
		}
		System.out.print('\u2588'+"   "+'\u2588'+"\r\n");
		System.out.print(" "+'\u2588'+"       "+'\u2588'+"       "+'\u2588'+"\r\n");
		System.out.print("  "+'\u2588'+"  "+'\u2588'+"  "+'\u2588'+'\u2588'+'\u2588'+"  "+'\u2588'+"  "+'\u2588'+"\r\n");
		System.out.print("  "+'\u2588'+"   "+'\u2588');
		for(int i = 0; i < 5; i++){
			System.out.print("_");
		}
		System.out.print('\u2588'+"   "+'\u2588'+"\r\n");
		System.out.print("   "+'\u2588'+'\u2588'+"         "+'\u2588'+'\u2588'+"\r\n");
		System.out.print("    ");
		for(int i = 0; i < 11; i++){
			System.out.print('\u2588');
		}
		System.out.print("\r\n");
		System.out.print("\r\n");
	}

	public static void interfacciaInferiore(int vite, int viteAttuale, int contaCure, int contaCureAttuale){
		System.out.print("Tua vita: "+viteAttuale+"/"+vite+'\r'+'\n');
		System.out.print("Numero di cure: "+contaCureAttuale+"/"+contaCure+'\r'+'\n');
	}
	
	public static void stampaCampo(char[][] posizione, int x, int y){
		for(int i = 0; i < 10; i++){
			for(int j = 0; j < 19; j++){
				if(y==i&&x==j){
					setForegroundColor(COLOR_RED);
					System.out.print(posizione[i][j]);
				}else{
					setForegroundColor(COLOR_BLACK);
					System.out.print(posizione[i][j]);
				}
			}
			System.out.print("\n"+"\r");
		}
	}
	
	public static void main(String[] args) {
		try {
			int vitaSans = 1000; //Vita del boss
			int vite = 100; //Vita del personaggio di un utente
			int contaCure = 3;
			boolean gioco = true;
			do {
				setForegroundColor(COLOR_BLUE);
				//menu
				System.out.print(""+' '+'\u2588'+'\u2588'+'\u2588'+' '+'\u2588'+'\u2588'+'\u2588'+' '+' '+' '+'\u2588'+'\u2588'+'\u2588'+' '+' '+' '+'\u2588'+'\u2588'+'\u2588'+"\r"+"\n");
				System.out.print(""+'\u2588'+' '+' '+' '+' '+' '+' '+' '+'\u2588'+' '+' '+'\u2588'+' '+' '+'\u2588'+' '+'\u2588'+"\r"+"\n");
				System.out.print(""+' '+'\u2588'+'\u2588'+' '+' '+' '+'\u2588'+'\u2588'+'\u2588'+' '+' '+'\u2588'+' '+' '+'\u2588'+' '+' '+'\u2588'+'\u2588'+"\r"+"\n");
				System.out.print(""+' '+' '+' '+'\u2588'+' '+'\u2588'+' '+' '+'\u2588'+' '+' '+'\u2588'+' '+' '+'\u2588'+' '+' '+' '+' '+'\u2588'+"\r"+"\n");
				System.out.print(""+'\u2588'+'\u2588'+'\u2588'+' '+' '+'\u2588'+'\u2588'+'\u2588'+'\u2588'+'\u2588'+' '+'\u2588'+' '+' '+'\u2588'+' '+'\u2588'+'\u2588'+'\u2588'+"\r"+"\n");
				System.out.print("Versione semplificata di Undertale"+"\r"+"\n");
				setForegroundColor(COLOR_BLACK);
				System.out.print("\r"+"\n");
				System.out.print("Fatto da M.Pasquini e L.Fumasoli"+"\r"+"\n");
				System.out.print("Giugno 2020"+"\r"+"\n");
				System.out.print("\r"+"\n");
				System.out.print("\r"+"\n");
				System.out.print("Usa [p] per giocare"+"\r"+"\n");
				System.out.print("Usa [c] per vedere i comandi"+"\r"+"\n");
				System.out.print("Usa [d] per modificare la difficolta\'"+"\r"+"\n");
				System.out.print("Usa [q] per uscire"+"\r"+"\n");
				for(int i = 0; i < 8; i++){
					System.out.print("\r"+"\n");
				}

				int scelta = System.in.read();
				System.out.print("\r"+"\n");

				/////////////////GIOCO////////////////
					if (scelta == 'p'){
						int vitaSansAttuale = vitaSans;
						int viteAttuale = vite;
						int contaCureAttuale = contaCure;
						int  gioco2 = 0;
						char[][] posizione = new char [10][19];
						int y = 5;
						int x = 9;
						int contaTurno = 0;
						int dannoSubito = 0;
						boolean occhioDestro = false;
						do {
							do {
								//Turno Sans
								int random10 = 1 + (int)(Math.random()*((7 - 1)+1));
								int random20 = 1 + (int)(Math.random()*((16 - 1)+1));
								int random30 = 1 + (int)(Math.random()*((7 - 1)+1));
								int random40 = 1 + (int)(Math.random()*((16 - 1)+1));

								//Modalità Normale (1s)///////////////////////////////////////////////////
								if(gioco2==0){
									occhioDestro = false;
									int secondi = 0;
									do{
										for(int i = 0; i < 10; i++){
											for(int j = 0; j < 19; j++){
												if(i==0&&j==0){
													posizione[i][j] = '\u250F';
												}else if(i==0&&j==18){
													posizione[i][j] = '\u2513';
												}else if(i==9&&j==0){
													posizione[i][j] = '\u2517';
												}else if(i==9&&j==18){
													posizione[i][j] = '\u251B';
												}else if((i==0||i==9)&&((i+j>=1&&i+j<=17)||(i+j>=10&&i+j<=26))){
													posizione[i][j] = '\u2501'; // -
												}else if((j==0||j==18)&&((i+j>=1&&i+j<=9)||(i+j>=19&&i+j<=26))){
													posizione[i][j] = '\u2503'; //|
												}else if(y==i&&x==j){
													posizione[i][j] = '\u2665';
												}else{
													posizione[i][j] = ' ';
												}
											}
										}
										interfacciaSuperiore(vitaSans, vitaSansAttuale, occhioDestro);
										stampaCampo(posizione, x, y);
										interfacciaInferiore(vite, viteAttuale, contaCure, contaCureAttuale);
										
										if(System.in.available()>0){
											scelta = System.in.read();
											if(scelta == 'w') {
												if (y > 1) {
													y--;
												}
											}else if(scelta =='s'){
												if (y < 8) {
													y++;
												}
											}else if(scelta =='d'){
												if (x < 17) {
												x++;
												}
											}else if(scelta == 'a'){
												if (x > 1) {
													x--;
												}
											}else if(scelta == 'q'){
												gioco2 = 1;
												contaTurno = 5;
											}
										}
										try{
											Thread.sleep(40);
										}catch(InterruptedException iex){
										}
										secondi++;
										System.out.print("\r"+"\n");
									}while(secondi<=25&&gioco2==0);
								}

							//modalità avviso (1s)//////////////////////////////////////////
								if(gioco2==0){
									occhioDestro = false;
									int secondi = 0;
									do{
										for(int i = 0; i < 10; i++){
											for(int j = 0; j < 19; j++){
												if(i==0&&j==0){
													posizione[i][j] = '\u250F';
												}else if(i==0&&j==18){
													posizione[i][j] = '\u2513';
												}else if(i==9&&j==0){
													posizione[i][j] = '\u2517';
												}else if(i==9&&j==18){
													posizione[i][j] = '\u251B';
												}else if(i==random10&&j==18){ //mette nel bordo dx
													posizione[i][18] = '\u2588';
													
												}else if(i==random30&&j==0){
													posizione[i][0] = '\u2588';
												
												}else if(j==random20&&i==0){ //mette nel bordo top
													posizione[0][j] = '\u2588';
												
												}else if(j==random40&&i==9){
													posizione[9][j] = '\u2588';
													
												}else if((i==0||i==9)&&((i+j>=1&&i+j<=17)||(i+j>=10&&i+j<=26))){
													posizione[i][j] = '\u2501'; // -
												}else if((j==0||j==18)&&((i+j>=1&&i+j<=9)||(i+j>=19&&i+j<=26))){
													posizione[i][j] = '\u2503'; //|
												}else if(y==i&&x==j){
													posizione[i][j] = '\u2665';
												}else{
													posizione[i][j] = ' ';
												}
											}
										}

										interfacciaSuperiore(vitaSans, vitaSansAttuale, occhioDestro);
										stampaCampo(posizione, x ,y);
										interfacciaInferiore(vite, viteAttuale, contaCure, contaCureAttuale);
										
										if(System.in.available()>0){
											scelta = System.in.read();
											if(scelta == 'w') {
												if (y > 1) {
													y--;
												}
											}else if(scelta =='s'){
												if (y < 8) {
													y++;
												}
											}else if(scelta =='d'){
												if (x < 17) {
													x++;
												}
											}else if(scelta == 'a'){
												if (x > 1) {
													x--;
												}
											}else if(scelta == 'q'){
												gioco2 = 1;
												contaTurno = 5;
											}
										}
										try{
											Thread.sleep(40);
										}catch(InterruptedException iex){
										}
										secondi++;
										System.out.print("\r"+"\n");
									}while(secondi<=25&&gioco2==0);
								}

								//modalità attacco (1s)//////////////////////////////////////
								if(gioco2==0){
									occhioDestro = true;
									int secondi = 0;
									do{
										for(int i = 0; i < 10; i++){
											for(int j = 0; j < 19; j++){
												if(i==0&&j==0){
													posizione[i][j] = '\u250F';
												}else if(i==0&&j==18){
													posizione[i][j] = '\u2513';
												}else if(i==9&&j==0){
													posizione[i][j] = '\u2517';
												}else if(i==9&&j==18){
													posizione[i][j] = '\u251B';
												}else if(i==random10){ //mette nel bordo dx
													posizione[i][j] = '\u2588';
													
												}else if(i==random30){
													posizione[i][j] = '\u2588';
													
												}else if(j==random20){ //mette nel bordo top
													posizione[i][j] = '\u2588';
													
												}else if(j==random40){
													posizione[i][j] = '\u2588';
													
												}else if((i==0||i==9)&&((i+j>=1&&i+j<=17)||(i+j>=10&&i+j<=26))){
													posizione[i][j] = '\u2501'; // -
												}else if((j==0||j==18)&&((i+j>=1&&i+j<=9)||(i+j>=19&&i+j<=26))){
													posizione[i][j] = '\u2503'; //|
												}else if(y==i&&x==j){
													posizione[i][j] = '\u2665';
												}else{
													posizione[i][j] = ' ';
												}
											}
										}
										if(dannoSubito == 0){
											if(y==random10||y==random30||x==random20||x==random40){
												int danno = 1 + (int)(Math.random()*((15 - 1)+1));
												viteAttuale = viteAttuale - danno;
												dannoSubito++;
											}
										}
										interfacciaSuperiore(vitaSans, vitaSansAttuale, occhioDestro);
										stampaCampo(posizione, x, y);
										interfacciaInferiore(vite, viteAttuale, contaCure, contaCureAttuale);
										
										if(System.in.available()>0){
											scelta = System.in.read();
											if(scelta == 'w') {
												if (y > 1) {
													y--;
												}
											}else if(scelta =='s'){
												if (y < 8) {
													y++;
												}
											}else if(scelta =='d'){
												if (x < 17) {
													x++;
												}
											}else if(scelta == 'a'){
												if (x > 1) {
													x--;
												}
											}else if(scelta == 'q'){
												gioco2 = 1;
												contaTurno = 5;
											}
										}
										try{
											Thread.sleep(40);
										}catch(InterruptedException iex){
										}
										secondi++;
										System.out.print("\r"+"\n");
									}while(secondi<=25&&gioco2==0);
								}
								dannoSubito = 0;
								contaTurno++;
								if (viteAttuale <= 0) {
									gioco2 = 2;
								}
							}while(gioco2==0&&contaTurno <= 5);
							contaTurno = 0;
							if(gioco2==0){
								occhioDestro = false;
								int turnoUtente = 0;
								int random1 = 0;
								///Turno utente
								do {
									interfacciaSuperiore(vitaSans, vitaSansAttuale, occhioDestro);
									for(int i = 0; i < 7; i++){
										System.out.print("\r"+"\n");
									}
									setForegroundColor(COLOR_YELLOW);
									for(int i = 0; i < 2; i++){
										System.out.print('\u250F');
										for(int j = 0; j < 6; j++){
											System.out.print('\u2501');
										}
										System.out.print('\u2513'+"     ");
									}
									System.out.print("\r\n");
									System.out.print('\u2503'+"ATTACK"+'\u2503'+"     "+'\u2503'+" HEAL "+'\u2503'+"\r\n");
									for(int i = 0; i < 2; i++){
										System.out.print('\u2517');
										for(int j = 0; j < 6; j++){
											System.out.print('\u2501');
										}
										System.out.print('\u251B'+"     ");
									}
									System.out.print("\r\n");
									setForegroundColor(COLOR_BLACK);
									interfacciaInferiore(vite, viteAttuale, contaCure, contaCureAttuale);
									scelta = System.in.read();
									System.out.print("\r\n");
									if(scelta == 'g') {
										random1 = (int)(Math.random() * 50)+50;
										vitaSansAttuale = vitaSansAttuale - random1;
										turnoUtente = 1;
									} else if(scelta == 'h' && contaCureAttuale > 0){
										random1 = (int)(Math.random() * 15)+5;
										viteAttuale = viteAttuale + random1;
										if (viteAttuale>100){
											viteAttuale=100;
										}
										contaCureAttuale--;
										turnoUtente = 1;
									}else if(scelta=='q'){
										gioco2=1;
										turnoUtente = 1;
									}else{
										System.out.print("Premi [a] per attacare o [h] se hai ancora cure" + "\r\n");
									}
								}while(turnoUtente == 0);
							}
							if(vitaSansAttuale <= 0){
								gioco2 = 3;
							}
						}while(gioco2 == 0);
						if (gioco2 == 2) {
							System.out.print("GAME OVER"+"\r\n");
							System.out.print("Premere qualsiasi pulsante per tornare al menu");
							for (int i=0;i<22;i++){
								System.out.print("\r\n");
							}
							scelta = System.in.read();
							System.out.print("\r\n");
							
						} else if(gioco2 == 3) {
							System.out.print("YOU WON"+"\r\n");
							System.out.print("Premere qualsiasi pulsante per tornare al menu");
							for (int i=0;i<22;i++){
								System.out.print("\r\n");
							}
							scelta = System.in.read();
							System.out.print("\r\n");
						}
						
					}else if (scelta == 'd'){ //////DIFFICOLTA//////
						boolean settaggio = true;
						do {
							System.out.print("-- DIFFICOLTA --"+"\r"+"\n"+"\r"+"\n");
							System.out.print("Vita Sans attuale = "+vitaSans+"\r"+"\n");
							System.out.print("Tua vita attuale = "+vite+"\r"+"\n");
							System.out.print("Numero di cure = "+contaCure+"\r"+"\n");
							System.out.print("\r"+"\n");
							System.out.print("Seleziona uno delle tre difficolta' elencati, se cambi la difficolta' il numero delle vite dei personaggi e il numero delle cure viene cambiato:"+"\r"+"\n");
							System.out.print("[f] per facile"+"\r"+"\n");
							System.out.print("[m] per medio"+"\r"+"\n");
							System.out.print("[d] per difficile"+"\r"+"\n");
							System.out.print("\r"+"\n");
							System.out.print("usa [q] per tornare al menu"+"\r"+"\n");

							for(int i = 0; i < 10; i++){
								System.out.print("\r"+"\n");
					  	}
							scelta = System.in.read();
							System.out.print("\r"+"\n");
							if (scelta == 'f') { //Vita boss
								vitaSans = 500;
								vite = 150;
								contaCure = 5;
							}else if (scelta == 'm') { //Vita pers. di un utente
								vitaSans = 1000;
								vite = 100;
								contaCure = 3;
							} else if (scelta == 'd') { //Vita pers. di un utente
								vitaSans = 1500;
								vite = 75;
								contaCure = 1;
							}else if (scelta == 'q') {
								settaggio = false;
							} else{
								System.out.print("Immettere una delle lettere accettate"+"\r"+"\n");
							}
						}while (settaggio);
						//////FINE DIFFICOLTA//////
					}else if (scelta == 'c') { //////COMANDI//////
						System.out.print("-- COMANDI --"+"\r"+"\n"+"\r"+"\n");
						System.out.print("Durante il turno di Sans:"+"\r"+"\n");
						System.out.print("Usa [w] per salire"+"\r"+"\n");
						System.out.print("Usa [s] per scendere"+"\r"+"\n");
						System.out.print("Usa [d] per andare a destra"+"\r"+"\n");
						System.out.print("Usa [a] per andare a sinistra"+"\r"+"\n");
						System.out.print("\r"+"\n");
						System.out.print("Durante il tuo turno:"+"\r"+"\n");
						System.out.print("Usa [g] per attaccare"+"\r"+"\n");
						System.out.print("Usa [h] per curarti"+"\r"+"\n");
						System.out.print("\r"+"\n");
						System.out.print("Durante qualsiasi turno:"+"\r"+"\n");
						System.out.print("Usa [q] per uscire dal gioco"+"\r"+"\n");
						System.out.print("\r"+"\n");
						System.out.print("Schiaccia qualsiasi tasto per tornare al menu"+"\r"+"\n");
						for(int i = 0; i < 7; i++){
							System.out.print("\r"+"\n");
						}
						System.in.read();
						System.out.print("\r"+"\n");
						//////FINE COMANDI//////
					}else if (scelta == 'q') { //////TERMINARE GIOCO//////
						
						gioco = false;
						//////FINE TERMINARE GIOCO//////
					}else {
						System.out.print("Immettere una delle lettere accettate"+"\r"+"\n");
					}
			}while(gioco);
		}catch (IOException e) {
			System.out.print("Errore"+"\r"+"\n");
		}
	}
}
