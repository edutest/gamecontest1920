#!/bin/bash
stty raw
java MarioJumper
stty -raw
